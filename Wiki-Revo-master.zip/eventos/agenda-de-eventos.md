---
description: Lista com horário dos eventos.
cover: ../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# ⏰ Horário

<table><thead><tr><th>Evento</th><th>Dia da Semana</th><th>Horário</th><th data-hidden></th></tr></thead><tbody><tr><td>Evento Gladiador (mcMMO)</td><td>Domingo</td><td>16:00 (Horário de Brasília)</td><td></td></tr><tr><td><a href="eventos-survival/guerra-de-clas.md">Evento Guerra (mcMMO)</a></td><td>Domingo</td><td>18:00 (Horário de Brasília)</td><td></td></tr><tr><td>Evento Lanceiro</td><td>Segunda-feira</td><td>18:00 (Horário de Brasília)</td><td></td></tr><tr><td>Evento Pré Clã x Clã</td><td>Segunda-feira</td><td>19:30 (Horário de Brasília)</td><td></td></tr><tr><td><a href="eventos-do-servidor/evento-arqueiro.md">Evento Arqueiro</a></td><td>Terça-feira</td><td>18:00 (Horário de Brasília)</td><td></td></tr><tr><td>Evento Pré Guerra</td><td>Terça-feira</td><td>19:30 (Horário de Brasília)</td><td></td></tr><tr><td>Evento Pré Guerra com Construção</td><td>Quarta-feira</td><td>19:30 (Horário de Brasília)</td><td></td></tr><tr><td>Evento Besteiro</td><td>Quinta-feira</td><td>18:00 (Horário de Brasília)</td><td></td></tr><tr><td><a href="eventos-survival/evento-pre-guerra-de-clas-mcmmo.md">Evento Pré Guerra (mcMMO)</a></td><td>Quinta-feira</td><td>19:30 (Horário de Brasília)</td><td></td></tr><tr><td><a href="eventos-survival/evento-killer.md">Evento Killer</a></td><td>Sexta-feira</td><td>18:00 (Horário de Brasília)</td><td></td></tr><tr><td>Evento Clã x Clã</td><td>Sexta-feira</td><td>19:30 (Horário de Brasília)</td><td></td></tr><tr><td>Evento Guerreiro</td><td>Sábado</td><td>16:00 (Horário de Brasília)</td><td></td></tr><tr><td>Evento Guerra com Construção</td><td>Sábado</td><td>18:00 (Horário de Brasília)</td><td></td></tr></tbody></table>

