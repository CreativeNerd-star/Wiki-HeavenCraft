---
description: Saiba todas as informações sobre o evento temporal Desbravador!
cover: ../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🗺 Evento Desbravador

## » Histórico do Evento

<table><thead><tr><th align="center">» Edição «</th><th align="center">» Vencedor(a) «</th><th data-hidden></th></tr></thead><tbody><tr><td align="center">Edição I, Temporada Medieval</td><td align="center"><code>N/A</code></td><td></td></tr><tr><td align="center">Edição II, Temporada SteamPunk</td><td align="center"><code>Carros2</code></td><td></td></tr><tr><td align="center">Edição III, Temporada Pirata</td><td align="center"><code>VITAOVM</code></td><td></td></tr><tr><td align="center">Edição IV, Temporada Tropical</td><td align="center"><code>*DaviZoneZ</code></td><td></td></tr><tr><td align="center">Edição V, Temporada Velho Oeste</td><td align="center"><code>AUGUSTUS15</code></td><td></td></tr><tr><td align="center">Edição VI, Temporada Apocalíptica</td><td align="center"><code>kauan0</code></td><td></td></tr><tr><td align="center">Edição VII, Temporada Glacial</td><td align="center"><code>KKlauz</code></td><td></td></tr><tr><td align="center">Edição VIII, Temporada Espacial</td><td align="center"><code>kelton1223</code></td><td></td></tr><tr><td align="center">Edição IX, Temporada Aquática</td><td align="center"><code>*Tilapia3154</code></td><td></td></tr><tr><td align="center">Edição X, Temporada Jurássica</td><td align="center"><code>-</code></td><td></td></tr></tbody></table>
