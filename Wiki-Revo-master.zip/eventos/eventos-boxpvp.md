---
description: Guia com todas as informações necessárias sobre os eventos do BoxPvP.
---

# Eventos

