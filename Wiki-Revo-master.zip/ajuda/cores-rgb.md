---
description: Como colorir suas mensagens ou seu nick
cover: ../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🎨 Cores RGB

#### Para criar degradês [clique aqui](https://rgb.rederevo.com/)!  Uso de cores RGB no nick para VIP's:&#x20;

/nick `&#00FFE0`Ne`&#EB00FF`Visk

#### [Site com códigos HEX](https://color-hex.com/)

#### Uso de cores RGB no chat para VIP's.&#x20;

Ex: `/g #FF0000<mensagem>`
