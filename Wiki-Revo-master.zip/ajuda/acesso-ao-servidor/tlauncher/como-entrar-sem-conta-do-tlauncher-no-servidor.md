---
description: >-
  Não consegue entrar no servidor porque não tem uma conta no TLauncher? Aqui
  está a solução para o seu problema!
cover: ../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# ❓ Como entrar sem conta do TLauncher no Servidor?

Basta desmarcar a opção "Contas" na área de login.

![](<../../../.gitbook/assets/image (1) (1) (1) (1) (2).png>)
