---
description: >-
  Nem todos os jogadores de Minecraft possuem uma conta original, então aqui
  temos algumas dicas para resolução de problemas comuns no TLauncher
cover: ../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🚀 TLauncher

Caso queira baixar o TLauncher [clique aqui](https://tlauncher.org/)!
