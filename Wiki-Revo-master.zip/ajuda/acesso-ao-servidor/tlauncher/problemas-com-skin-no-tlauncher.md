---
description: >-
  Ao entrar no servidor você não consegue ver a skin correta dos jogadores? Aqui
  você encontrará a solução para o seu problema!
cover: ../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 👕 Problemas com skin no Tlauncher?

Desative o sistema de skins(peles) do TLauncher desmarcando a opção `Use peles TLauncher` para visualizar as skins corretas dos jogadores.

![](<../../../.gitbook/assets/image (1) (1) (1) (1) (1).png>)
