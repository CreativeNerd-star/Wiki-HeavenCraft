---
description: Aceitamos Minecraft Versão Java e Bedrock Edition!
cover: ../../.gitbook/assets/bannercomfundorevo.png
coverY: 0
---

# 📬 Acesso ao servidor

