---
cover: ../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 📱 Discord

> Este servidor segue os [**Termos de serviço do Discord**](https://discord.com/terms) e estamos de acordo com as [𝐃𝐢𝐫𝐞𝐭𝐫𝐢𝐳𝐞𝐬 𝐝𝐚 𝐂𝐨𝐦𝐮𝐧𝐢𝐝𝐚𝐝𝐞 𝐝𝐨 𝐃𝐢𝐬𝐜𝐨𝐫𝐝](https://discord.com/guidelines), portanto, dependendo do que ocorrer o usuário poderá ter sua conta desativada da plataforma!

{% hint style="danger" %}
Caso você quebre algum dos [𝐃𝐢𝐫𝐞𝐭𝐫𝐢𝐳𝐞𝐬 𝐝𝐚 𝐂𝐨𝐦𝐮𝐧𝐢𝐝𝐚𝐝𝐞 𝐝𝐨 𝐃𝐢𝐬𝐜𝐨𝐫𝐝](https://discord.com/guidelines) você terá a conta banida de nosso discord.
{% endhint %}

## Regra 20 - Autopromoção <a href="#01" id="01"></a>

É proibido fazer autopromoção (convites de servidor, anúncios, etc) sem permissão de um membro da equipe. Isso inclui status, sobre mim e mandar DM's para outros membros.

<table><thead><tr><th width="150" align="center">Incidência</th><th align="center">Punição</th></tr></thead><tbody><tr><td align="center">1</td><td align="center">Expulsão do Discord</td></tr><tr><td align="center">2</td><td align="center">Banimento permanente</td></tr></tbody></table>

## Regra 21 - Fugir do Assunto em Tópicos <a href="#01" id="01"></a>

O Discord é nosso principal meio de comunicação e diversas vezes tópicos são criados para discussões importantes, ouvir opinião de vocês e muito mais. Com isso, o jogador que entrar no tópico com o intuito de atrapalhar e/ou ficar fugindo do assunto debatido será punido.

<table><thead><tr><th width="150" align="center">Incidência</th><th align="center">Punição</th></tr></thead><tbody><tr><td align="center">1</td><td align="center"><a href="https://support.discord.com/hc/en-us/articles/4413305239191-Time-Out-FAQ">Castigo</a> de <strong>7 dias</strong>.</td></tr></tbody></table>

{% hint style="warning" %}
A quebra de qualquer regra de [chat](chat.md) ocasionará em castigo de **7 dias**.
{% endhint %}
