---
description: Colecione "troféus" ao abater inimigos e decapitá-los.
cover: ../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 💀 Cabeças

Ao abater um jogador tenha chance de decapitar um inimigo e receber a cabeça (item) do mesmo como recompensa, para cada cargo consta uma maior probabilidade:\


<table><thead><tr><th width="374" align="center">Cargo</th><th align="center">Chance</th></tr></thead><tbody><tr><td align="center">Super</td><td align="center">15%</td></tr><tr><td align="center">Ultra</td><td align="center">20%</td></tr><tr><td align="center">Legend</td><td align="center">25%</td></tr><tr><td align="center">Especial</td><td align="center">30%</td></tr></tbody></table>
