---
description: >-
  Jogadores que estiverem no top no final de temporada, serão recompensados com
  itens e tags exclusivas na troca da mesma.
---

# 🏆 Hall da Fama

### Cash TOP

O top 1 atual do ranking recebe os seguintes destaques:

* ![](<../../.gitbook/assets/image (7).png>) ícone no TAB, chat e nome.
* Aviso de entrada ao entrar no servidor.

<table><thead><tr><th align="center">Posição</th><th width="195" align="center">TAG</th><th width="163" align="center">Liga</th><th align="center">Troféu</th></tr></thead><tbody><tr><td align="center">1</td><td align="center"><img src="../../.gitbook/assets/image (20).png" alt=""></td><td align="center">+250</td><td align="center">✔️</td></tr><tr><td align="center">2</td><td align="center"><img src="../../.gitbook/assets/image (4).png" alt=""></td><td align="center">+200</td><td align="center"><a href="https://emojiterra.com/pt/x-vermelho/">❌</a></td></tr><tr><td align="center">3</td><td align="center"><img src="../../.gitbook/assets/image (26).png" alt=""></td><td align="center">+150</td><td align="center"><a href="https://emojiterra.com/pt/x-vermelho/">❌</a></td></tr></tbody></table>
