---
description: 'Segue a lista de tudo que é resetado na troca de temporada:'
---

# 🔁 Resets

* Rankings:&#x20;
  * Kill TOP
  * Blocos TOP
  * Online TOP
  * Votos TOP
* Passe de Batalha
* Temática do mundo (spawn e arena)
