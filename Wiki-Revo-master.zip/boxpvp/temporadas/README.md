---
description: >-
  Temporadas duram em média 90 dias e alteram coisas diversas de nossos
  servidores.
cover: ../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🎲 Temporadas

## &#x20;Informações

As Temporadas no BoxPvP são períodos que tematizam o servidor em relação a construções, itens, tags, eventos, etc...

Na mudança de temporada, as construções e passe de batalha do servidor são adaptados ao tema, além de iniciar um novo passe de batalha.

{% hint style="info" %}
Durante as trocas de temporada **NENHUM** progresso é perdido (Exceto ranking de temporada) e uma nova temática é aplicada.
{% endhint %}
