---
description: Celebre Seu Aniversário na Rede Revo com um super desconto especial! 🎉
---

# 🎂 Desconto de Aniversario

No dia do seu aniversário, presenteamos você com um cupom exclusivo de **40% de desconto** (uso único) em todos os pacotes de cash disponíveis. Para aproveitar essa oferta especial, siga os passos abaixo:

1. **Solicite seu cupom**: Entre em contato conosco via ticket em nosso servidor do [Discord](https://discord.gg/rederevo). Informe que deseja resgatar seu cupom de aniversário.
2. **Comprove seu Aniversário**: Para validar sua solicitação, é necessário enviar uma imagem de um documento de identificação oficial (com foto) que esteja validado no sistema do governo. Certifique-se de que o documento esteja legível e que a data de nascimento esteja clara.
3. **Informações de Pagamento**: O meio de pagamento utilizado para a compra deve estar registrado no mesmo CPF/NIF constante no documento de identificação enviado.

Lembramos que o cupom de aniversário é de uso único e exclusivo para o titular do aniversário. Aproveite essa oportunidade para celebrar seu dia com ainda mais alegria!

Caso tenha dúvidas ou precise de assistência, nossa equipe está à disposição para ajudá-lo.
