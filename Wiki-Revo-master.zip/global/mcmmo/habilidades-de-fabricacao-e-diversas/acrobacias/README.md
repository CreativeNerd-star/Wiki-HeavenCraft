---
description: >-
  Reduza o dano de quedas aprimorando esta habilidade. Habilidade focada em
  quedas graciosas!
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 👞 Acrobacias

![](../../../../.gitbook/assets/AcrobaticsSkill.webp)

## » Habilidades

{% content-ref url="rolar.md" %}
[rolar.md](rolar.md)
{% endcontent-ref %}

{% content-ref url="esquivar.md" %}
[esquivar.md](esquivar.md)
{% endcontent-ref %}

## » Técnicas

## » Tabela de EXP ganho

<table><thead><tr><th>» Ação «</th><th align="center">» EXP «</th><th data-hidden></th></tr></thead><tbody><tr><td><img src="../../../../.gitbook/assets/Botas_de_Couro.webp" alt="" data-size="line"> Ao cair</td><td align="center">600</td><td></td></tr><tr><td><img src="../../../../.gitbook/assets/Botas_de_Diamante.webp" alt="" data-size="line"> Ao <a href="rolar.md">rolar</a></td><td align="center">600</td><td></td></tr><tr><td><img src="../../../../.gitbook/assets/Netherite_Boots_JE2_BE1.webp" alt="" data-size="line"> Ao <a href="esquivar.md">esquivar</a> de um ataque</td><td align="center">800</td><td></td></tr></tbody></table>
