---
description: >-
  Essas habilidades podem lhe fornecer uma maior eficiência na fabricação,
  fabricações exclusivas, etc.
cover: ../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🔨 Habilidades de Fabricação e Diversas

## » Habilidades de fabricação e diversas

{% content-ref url="reparacao/" %}
[reparacao](reparacao/)
{% endcontent-ref %}

{% content-ref url="alquimia/" %}
[alquimia](alquimia/)
{% endcontent-ref %}

{% content-ref url="fundicao/" %}
[fundicao](fundicao/)
{% endcontent-ref %}

## » Habilidades diversas

{% content-ref url="acrobacias/" %}
[acrobacias](acrobacias/)
{% endcontent-ref %}
