---
description: Aprimore a fabricação de poções com a habilidade de Alquimia!
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🪄 Alquimia

![](../../../../.gitbook/assets/AlchemySkill.webp)

## » Habilidades

## » Técnicas

## » Tabela de EXP ganho

{% hint style="info" %}
O EXP recebido não é definido pelo ingrediente usado, e sim pela quantidade de ingredientes usados para fazer a poção.
{% endhint %}

<table><thead><tr><th>» Poção «</th><th align="center">» EXP «</th><th data-hidden></th></tr></thead><tbody><tr><td><img src="../../../../.gitbook/assets/Potion_of_Leaping_JE2_BE2.webp" alt="" data-size="line"> Poção de 1 ingrediente</td><td align="center">15</td><td></td></tr><tr><td><img src="../../../../.gitbook/assets/Potion_of_Poison_JE1_BE1.webp" alt="" data-size="line"> Poção de 2 ingredientes</td><td align="center">30</td><td></td></tr><tr><td><img src="../../../../.gitbook/assets/Potion_of_Swiftness_JE1_BE1.webp" alt="" data-size="line"> Poção de 3 ingredientes</td><td align="center">60</td><td></td></tr><tr><td><img src="../../../../.gitbook/assets/Potion_of_Water_Breathing_JE2_BE2.webp" alt="" data-size="line"> Poção de 4 ingredientes</td><td align="center">120</td><td></td></tr><tr><td><img src="../../../../.gitbook/assets/Potion_of_Fire_Resistance_JE1_BE1.webp" alt="" data-size="line"> Poção de 5 ingredientes</td><td align="center">240</td><td></td></tr><tr><td><img src="../../../../.gitbook/assets/Imagem-Poção-Minecraft-PNG.png" alt="" data-size="line"> Poção de 6 ingredientes</td><td align="center">240</td><td></td></tr></tbody></table>
