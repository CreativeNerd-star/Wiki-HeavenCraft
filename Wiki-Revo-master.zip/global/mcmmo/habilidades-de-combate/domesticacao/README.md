---
description: Aprimore a luta com animais domesticáveis com esta habilidade!
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🦴 Domesticação

![](../../../../.gitbook/assets/TamingSkill.webp)

## » Habilidades

{% content-ref url="conhecimento-de-feras.md" %}
[conhecimento-de-feras.md](conhecimento-de-feras.md)
{% endcontent-ref %}

{% content-ref url="chamado-da-natureza.md" %}
[chamado-da-natureza.md](chamado-da-natureza.md)
{% endcontent-ref %}

{% content-ref url="consciencia-ambiental.md" %}
[consciencia-ambiental.md](consciencia-ambiental.md)
{% endcontent-ref %}

{% content-ref url="patada.md" %}
[patada.md](patada.md)
{% endcontent-ref %}

{% content-ref url="servico-de-fast-food.md" %}
[servico-de-fast-food.md](servico-de-fast-food.md)
{% endcontent-ref %}

{% content-ref url="mordida.md" %}
[mordida.md](mordida.md)
{% endcontent-ref %}

{% content-ref url="pelo-grosso.md" %}
[pelo-grosso.md](pelo-grosso.md)
{% endcontent-ref %}

{% content-ref url="cao-piedoso.md" %}
[cao-piedoso.md](cao-piedoso.md)
{% endcontent-ref %}

{% content-ref url="resistencia-a-impactos.md" %}
[resistencia-a-impactos.md](resistencia-a-impactos.md)
{% endcontent-ref %}

{% content-ref url="garras-afiadas.md" %}
[garras-afiadas.md](garras-afiadas.md)
{% endcontent-ref %}

## » Técnicas

## » Tabela de EXP ganho
