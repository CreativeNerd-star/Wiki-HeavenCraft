---
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🏋 Quebra de Limite de Desarmado

