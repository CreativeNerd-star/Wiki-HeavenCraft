---
description: Cause mais dano com machados!
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🎩 Maestria com Machados

Maestria com Machados inflige mais dano dependendo do nível do machado. A maestria com machados aumenta o dano causado por machados em 0,02 por nível, limitando +4 de dano bônus no nível 200.

* [x] Requer nível 50.
* [x] Aplicável contra mobs e jogadores.
* [x] Habilidade passiva.
