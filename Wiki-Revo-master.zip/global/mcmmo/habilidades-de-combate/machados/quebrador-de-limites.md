---
description: Quebre o limite de dano dos machados!
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 💪 Quebra de Limite com Machados

Esta habilidade quebra o limite prefixo de dano no qual seu machado causa. O dano adicional é fixo.

* [x] Habilidade passiva.
* [x] Aplicável contra mobs e jogadores.
