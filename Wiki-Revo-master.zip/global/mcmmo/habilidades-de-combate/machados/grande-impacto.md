---
description: Cause Knockback e mais dano em inimigos!
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🪓 Grande Impacto

Grande Impacto é uma habilidade passiva que na batalha contra a armadura de mobs e jogadores sem armadura, adiciona 2 de dano extra (1 coração). Grande Impacto também adiciona um efeito Knockback extremo semelhante ao Knockback II em uma espada e faz um som explosivo quando ativado. Grande Impacto tem uma porcentagem de chance de ser acionado a cada acerto.

* [x] Requer nível 250.
* [x] Aplicável contra jogadores e mobs.
* [x] Habilidade passiva.
