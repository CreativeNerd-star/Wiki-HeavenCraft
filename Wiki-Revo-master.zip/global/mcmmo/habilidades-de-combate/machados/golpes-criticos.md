---
description: Cause danos críticos em oponentes!
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 💥 Golpes Críticos

Golpes Críticos aumentam a quantidade de dano que você causa com seu machado. Isso é ótimo para eliminar alvos de alta defesa. A habilidade dobra o dano causado em mobs e aumenta 1.5x o dano causado em jogadores. A chance de dar golpes críticos aumenta de acordo com o nível de habilidade de Machados.

* [x] Requer nível 1.
* [x] Aplicável contra mobs e jogadores.
* [x] Habilidade passiva.
