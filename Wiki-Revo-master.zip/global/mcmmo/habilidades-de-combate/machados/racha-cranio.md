---
description: Cause dano em área com machados!
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 💀 Racha Crânio

Com um machado na mão, você pode clicar com o botão direito do mouse em um bloco, deixando sua habilidade ativa pronta para uso. A habilidade será então ativada ao acertar Mobs/Players. Esta habilidade funciona por um período limitado de tempo começando em 2 segundos, aumentando em 1 segundo a cada 50 níveis.

Esta habilidade causa dano em área. 50% do valor do dano causado em seu oponente será causado em inimigos em seus arredores.

* [x] Requer nível 50.
* [x] Aplicável contra mobs e jogadores.
* [x] Habilidade ativa: com o machado na mão clique com o botão direito em um bloco.
