---
description: Aumente o impacto causado em armaduras de oponentes com esta habilidade.
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🎆 Impacto em Armaduras

Impacto em Armaduras aumenta a quantidade de dano que um machado causa à armadura. Esta vantagem começa com um bônus de dano de armadura, aumentando em 0,02% por nível em machados. (Este número é sempre terminal)

* [x] Requer nível 1.
* [x] Aplicável em armaduras de oponentes.
* [x] Habilidade passiva.
