---
description: Evite gasto de flechas em seus tiros!
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# ⬆ Recuperação de Flechas

Recuperar é a habilidade de Arquearia de atirar sem perder suas flechas. Ganhar níveis adicionais no tiro com arco aumenta a chance de recuperar as flechas que dispararam. Isso é útil se você não tiver Infinidade em seu arco.

* [x] Requer nível 1.
* [x] Aplicável contra jogadores e mobs.
* [x] Habilidade passiva.
