---
description: Cause tontura em seus inimigos!
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 😵 Atordoar

Atordoar é um efeito que pode desencadear em alguns dos tiros do jogador, fazendo com que o inimigo se sinta atordoado. Ganhar níveis adicionais em Arquearia aumenta a chance de atordoar seu oponente. Este efeito não funciona em mobs.

Atordoar inflige náusea no alvo por 6 segundos e causa 4 de dano adicional. Náusea afeta apenas jogadores e não tem efeito em mobs não-jogadores.

A chance de Atordoar ocorrer é de 0,05% por hit por nível, limitando em 50% no nível 1000. Isso é igual a 1% a cada 20 níveis.

* [x] Requer nível 1.
* [x] Aplicável contra jogadores.
* [x] Não aplicável contra mobs.
* [x] Habilidade passiva.
