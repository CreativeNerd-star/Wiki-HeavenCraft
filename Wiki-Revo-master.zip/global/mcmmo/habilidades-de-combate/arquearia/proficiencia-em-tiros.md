---
description: Aumente o dano causado por arcos e bestas.
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🎯 Proficiência em Tiros

Habilidade que causa mais dano contra players e mobs, ganhar níveis de arquearia aumenta o dano do seu machado.

* [x] Requer nível 1.
* [x] Aplicável contra jogadores e mobs.
* [x] Habilidade passiva.
