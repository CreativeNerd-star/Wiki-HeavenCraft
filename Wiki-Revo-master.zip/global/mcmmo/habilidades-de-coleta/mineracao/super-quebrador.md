---
description: Mais velocidade + chance de drops triplos.
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# ⚒ Super Quebrador

* [x] Requer nível 50;
* [x] Mais velocidade;
* [x] Chance de drops triplos;
* [x] Habilidade ativa: clique com botão direito do mouse com uma picareta na mão.

Super Quebrador (ativado clicando com o botão direito do mouse com uma picareta na mão), adicionará temporariamente 5 níveis de eficiência à picareta segurada, triplicará a taxa de drop duplo e substituirá os drops duplos de taxa normal por drops triplos. Em outras palavras, o Super Quebrador se acumula com os encantamentos da Fortuna 3.

A duração da habilidade começa em 2 segundos e aumenta em 1 segundo a cada 50 níveis. Não há duração máxima. Como todas as habilidades, seu tempo de espera padrão é de 240 segundos. Desequipar a picareta fará com que o tempo restante com a habilidade seja desperdiçado e o tempo de espera comece mais cedo.
