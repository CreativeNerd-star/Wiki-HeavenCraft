---
description: Bônus para mineração com TNT.
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 💣 Mineração Explosiva

* [x] Requer nível 100;
* [x] Habilidade ativa.

Em vez de usar uma picareta para quebrar blocos, a Mineração Explosiva utiliza TNT para destruir e minerar blocos. Ele é ativado usando uma pederneira fora da caixa de colisão com TNT usado normalmente para ativá-la (clique com o botão direito do mouse no ar entre você e a TNT). Ao contrário da ignição vanilla, o TNT explode instantaneamente.

Com a Mineração explosiva, o alcance no qual a TNT explode é estendido. Níveis mais altos de mineração produzirão mais minérios e menos restos. Por padrão, o TNT diminui 30% do que é explodido e aumenta ainda mais a cada nível.
