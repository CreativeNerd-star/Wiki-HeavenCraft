---
description: Dobre os drops normais.
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🪶 Drops Duplos de Minérios

Drops duplos é uma habilidade passiva que permite ao jogador ganhar dois itens em vez do usual ao minerar qualquer bloco gerado naturalmente encontrado na tabela de experiência que lista os blocos que a Mineração faz efeito, em » [Mineração](./) «. As chances de isso acontecer aumentam em 0,1% por nível para um máximo de 100% no nível 1000. Ele não se acumula com o encantamento Fortuna, mas funciona com o Toque Suave.

* [x] Requer nível 1;
* [x] Aplicável com toque suave;
* [x] Não aplica em detrito ancestral;
* [x] Habilidade passiva;
* [x] Aplicável em blocos gerados naturalmente.
