---
description: Reduz o dano recebido por explosões de TNT.
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🦿 Experiente em Demolições

* [x] Requer nível 100;
* [x] Habilidade Passiva.

A habilidade Experiente em Demolições é uma habilidade passiva que reduz o dano causado por TNT com Mineração Explosiva em 25%. No nível 750, o dano é reduzido em 50%. No nível 1000, a redução de dano é de 100%.

Observe que o TNT incendiado por meios padrão ainda causa danos, e somente quando incendiado por Mineração Explosiva o dano é negado.
