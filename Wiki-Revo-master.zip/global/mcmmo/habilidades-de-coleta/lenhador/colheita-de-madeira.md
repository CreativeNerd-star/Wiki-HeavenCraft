---
description: Dobre seus drops!
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🌲 Colheita de Madeira

* [x] Habilidade passiva;
* [x] Requer nível 1.

Colheita de Madeira é uma habilidade passiva que permite que você ganhe dois itens em vez de um ao cortar qualquer tronco ou bloco de cogumelo gigante que foi gerado pelo mundo ou cultivado. A chance de obter drops duplos aumenta em 0,1% por nível até um máximo de 100% no nível 1000.
