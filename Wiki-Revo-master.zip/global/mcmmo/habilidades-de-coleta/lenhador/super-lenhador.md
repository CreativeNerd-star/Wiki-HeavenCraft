---
description: Mais velocidade de coleta de madeira.
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🌴 Super Lenhador

* [x] Requer nível 50;
* [x] Mais velocidade;
* [x] Chance de drops triplos;
* [x] Habilidade ativa: clique com botão direito do mouse com um machado na mão.

Fará com que seu machado se torne super eficiente e passe a quebrar instantaneamente troncos de árvores de até 200 blocos. Mas muito **cuidado**, será consumida a durabilidade do item, portanto preste muita atenção para não quebrar...&#x20;

A duração da habilidade começa em 2 segundos e aumenta em 1 segundo a cada 50 níveis. Como todas as habilidades, seu tempo de espera padrão é de 240 segundos. Desequipar o machado fará com que o tempo restante com a habilidade seja desperdiçado e o tempo de espera comece mais cedo.
