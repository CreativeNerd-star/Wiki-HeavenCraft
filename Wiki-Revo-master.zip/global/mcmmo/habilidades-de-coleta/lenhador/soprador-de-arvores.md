---
description: Sopre as folhas!
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🍃 Soprador de Árvores

* [x] Requer nível 100;
* [x] Habilidade passiva.

Soprador de Árvores é uma habilidade que fará com que os blocos de folhas se quebrem instantaneamente quando atingidos por um machado. Quando destruído usando o Soprador de Árvores, um bloco de folhas tem 10% de chance de derrubar sua respectiva muda. As folhas causam danos de durabilidade ao machado e fazem um som de estalo quando quebradas.
