---
description: Encontre tesouros com esta habilidade!
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🤞 Sorte de Hylian

Hylian Luck dá uma pequena chance de obter itens especiais quando certos blocos são quebrados com uma espada. Os blocos que são afetados por esta habilidade são:

* Grama&#x20;
* Mudas
* Arbustos
* Flores

A chance de queda aumenta 0,01% a cada nível. No entanto, a exibição é feita apenas com pontos percentuais inteiros. No nível 1000, as chances são de 10%.
