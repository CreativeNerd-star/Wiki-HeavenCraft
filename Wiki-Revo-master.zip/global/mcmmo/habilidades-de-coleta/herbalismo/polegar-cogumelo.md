---
description: Transforme terra em micélio com esta habilidade!
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🍄 Polegar Cogumelo

Usar um cogumelo em um bloco de terra enquanto um cogumelo vermelho e um marrom estão no inventário ativa seu "dedão". Ele consome um cogumelo vermelho e marrom e tem a chance de transformar o bloco de terra em um bloco de micélio. As chances de sucesso aumentam com o nível de Herbalismo.
