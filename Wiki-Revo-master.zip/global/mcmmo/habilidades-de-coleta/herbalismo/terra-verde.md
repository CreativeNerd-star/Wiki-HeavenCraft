---
description: Aprimore ainda mais sua colheita usando esta habilidade!
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🌻 Terra Verde

Segure shift e uma enxada e clique no ar com o botão direito. Ao quebrar uma planta após fazer o passo anterior, com Herbalismo nível 50 ou acima ativa a habilidade Terra Verde. Aumenta em duração em certos níveis. Tem um cooldown de 240 segundos.

#### Efeitos enquanto ativado

* Alta chance de triplicar todos os drops de plantas ou culturas cultiváveis, incluindo sementes.
* No farm, um potencial para replantar várias sementes gratuitamente durante a duração da habilidade, economizando tempo e sementes.
* Consome 1 semente de trigo para converter um dos seguintes blocos:
  * Pedregulho em Pedregulho Musgoso;
  * Tijolo de Pedra em Tijolo de Pedra Musgoso;
  * Terra em grama.
