---
description: Melhore a saciação de alimentos cultivados.
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🥦 Dieta do Fazendeiro

Essa habilidade passiva aumenta a quantidade de fome que a comida cultivada irá restaurar à medida que o nível de Herbalismo do jogador aumenta. Uma fome é metade de um pedaço de carne na barra de fome.

| Nível de Herbalismo | Classificação da Habilidade | Bônus de restauração da fome |
| :-----------------: | :-------------------------: | :--------------------------: |
|       0 - 199       |              -              |               0              |
|      200 - 399      |              I              |               1              |
|      400 - 599      |              II             |               2              |
|      600 - 799      |             III             |               3              |
|      800 - 999      |              IV             |               4              |
|        1000+        |              V              |               5              |
