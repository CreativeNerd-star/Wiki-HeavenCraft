---
description: Faça suas plantações crescer mais rapidamente!
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 👍 Polegar Verde

O Polegar Verde tem a capacidade de progredir mais rapidamente no crescimento de todas as culturas de bloco único. Abaixo uma tabela que leva a equação seguinte: nível\*(13,3%/200%)=chance. Estágio de crescimento é o estágio fixo que a plantação irá crescer de acordo com o nível. Chance é a chance de crescer instantaneamente no nível máximo de plantação.

| Nível de Herbalismo | Estágio de Crescimento |           Chance          |
| :-----------------: | :--------------------: | :-----------------------: |
|       0 - 199       |            0           |    (Nível 0) 0% - 13,3%   |
|      200 - 399      |            1           |       13.3% - 26.7%       |
|      400 - 599      |            2           |        26.7% - 40%        |
|      600 - 799      |            3           |        40% - 53.3%        |
|       800-1500      |            4           | 53,3% - 100% (Nível 1500) |
