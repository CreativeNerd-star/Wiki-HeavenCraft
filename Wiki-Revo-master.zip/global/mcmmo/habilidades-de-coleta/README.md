---
description: >-
  Habilidades de coleta são habilidades que são aprimoradas por meio de coletas
  de itens. Essas habilidades podem lhe fornecer um bônus de drops duplos, drops
  raros, melhoria na eficiência da coleta...
cover: ../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🌿 Habilidades de Coleta

## » Habilidades de coleta

{% content-ref url="mineracao/" %}
[mineracao](mineracao/)
{% endcontent-ref %}

{% content-ref url="lenhador/" %}
[lenhador](lenhador/)
{% endcontent-ref %}

{% content-ref url="herbalismo/" %}
[herbalismo](herbalismo/)
{% endcontent-ref %}

{% content-ref url="escavacao/" %}
[escavacao](escavacao/)
{% endcontent-ref %}

{% content-ref url="pesca/" %}
[pesca](pesca/)
{% endcontent-ref %}
