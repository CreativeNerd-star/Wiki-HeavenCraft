---
description: >-
  Temporadas duram em média 90 dias e alteram coisas diversas de nossos
  servidores.
cover: ../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🎲 Temporadas

> Temporadas basicamente são períodos (em média de 90 dias) que alteram os servidores em diversos aspectos.

### » Temporada - Survival

As Temporadas no Survival são períodos que tematizam o servidor em relação a construções, itens, tags, eventos, etc...



Na mudança de temporada, as construções e passe de batalha do servidor são adaptados ao tema, além de iniciar um novo passe de batalha.



_"O servidor reseta?"_ Não! Nenhum progresso será perdido, apenas serão inclusas diversas novidades em relação a temporada. Apenas os mundos **Nether** e **The End** serão resetados, possibilitando uma maior gama de recursos.



#### » Hall da Fama das Temporadas do Survival



> Jogadores que estiverem no top no final de temporada, serão recompensados com itens e tags exclusivas na troca dela.

![](../.gitbook/assets/att.png)

![](<../.gitbook/assets/unknown (4).png>)

![](<../.gitbook/assets/unknown (1).png>)

![](../.gitbook/assets/unknown.png)

![](<../.gitbook/assets/unknown (5).png>)

![](<../.gitbook/assets/unknown (3).png>)

![](<../.gitbook/assets/unknown (2).png>)





