---
description: >-
  Votar em nosso servidor não apenas ajuda a construir e manter a nossa
  comunidade, mas também oferece a oportunidade de ganhar prêmios exclusivos no
  jogo.
cover: ../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🔑 Votos

## Recompensas

Como forma de agradecimento pela contribuição com o servidor, para cada voto você recebe uma **Chave Misteriosa \[Comum]** que pode ser utilizado para abrir uma caixa misteriosa.
