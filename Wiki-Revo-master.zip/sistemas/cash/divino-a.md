---
description: O que é o cargo Divindade e como conseguir?
cover: ../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🌻 Divindade

#### Divindade é um cargo feito para os tops 1, 2 e 3 doadores em nosso [site](https://rederevo.com/) como uma forma de agradecimento por apoiar a Rede Revo.

### E quais são as vantagens de ter esse cargo?

* Tenha seu NPC exposto no Lobby.
* Receba destaque no TAB e Chat.
* Cargo exclusivo com destaque no discord.
* Não perde a sua cabeça ao morrer.
* Acesso ao `/brilhar` e `/colorido` em todos os servidores.

### Recompensas para quem estiver no TOP 1, 2 e 3 ao fechar o mês:

* Receba duas tags exclusivas **Divino** e **Divina.** (com duração de 1 mês e exclusiva para o top 1)
* Receberá um **Chapéu do Revonildo** (abra um ticket e diga em qual servidor deseja receber o item).&#x20;

{% hint style="info" %}
As vantagens só duram durante o mês em que você foi top doador(a)
{% endhint %}
