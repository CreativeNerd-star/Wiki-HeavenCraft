---
description: >-
  Existem 2 formas que você pode proteger a garantir uma maior segurança em sua
  conta:
---

# 🔒 Proteção

## Email

Vincule um email, utilize **/email add (email)** para adicionar um email em sua conta.

* Utilize /email 2fa para adicionar ainda mais segurança, uma nova verificação por email será efetuada sempre que seu IP mudar.

## Discord

Vincule sua conta com nosso [discord](https://discord.com/channels/793269891557490688/932722581222600794) siga os passos do canal **#vincular-conta** e sincronize também automaticamente seu nick e cargo.

<figure><img src="../.gitbook/assets/image.png" alt=""><figcaption></figcaption></figure>
