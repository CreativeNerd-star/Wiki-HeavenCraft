---
description: Eventos que ocorrem mensalmente.
---

# 📆 Mensais

