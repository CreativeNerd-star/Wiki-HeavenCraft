---
description: Eventos que ocorrem uma vez na semana.
---

# 🗓 Semanais

