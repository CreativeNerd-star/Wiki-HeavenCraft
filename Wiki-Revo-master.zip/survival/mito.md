---
description: Todas as informações importantes sobre o sistema de Mito são aqui encontradas!
cover: ../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🔝 Mito

![](<../.gitbook/assets/unknown (6).png>)

A TAG Mito é ganha no evento [Guerra de Clãs](../eventos/eventos-survival/guerra-de-clas.md), caso você seja o jogador matador. A TAG pode ser perdida a partir das seguintes ocasiões:

* Morrer por qualquer motivo;
* Comercializar a TAG, ou arquivá-la em conta secundária, vide [Regra 19 - Uso Irregular da TAG Mito](../regras/jogabilidade.md#01-8);
* Sair de evento para não morrer e consequentemente perder a TAG Mito;
* Ficar offline por 12 horas.

#### Como ganhar a TAG

* Sendo matador da [Guerra de Clãs](../eventos/eventos-survival/guerra-de-clas.md), assim como dito acima;
* Reportar infrator da [Regra 19 - Uso Irregular da TAG Mito](../regras/jogabilidade.md#01-8) e a denúncia ser aceita.
