---
description: >-
  Tutorial sobre o sistema de terrenos do servidor. Saiba como criar, expandir,
  compartilhar permissões, criar sub proteções e abandonar proteções.
cover: ../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🪵 Terrenos

## Tempo offline necessário para perda da proteção.

{% content-ref url="broken-reference" %}
[Broken link](broken-reference)
{% endcontent-ref %}
