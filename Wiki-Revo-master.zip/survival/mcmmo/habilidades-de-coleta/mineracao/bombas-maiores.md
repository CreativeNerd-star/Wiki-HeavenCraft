---
description: Aumenta o raio de explosão da habilidade Mineração Explosiva.
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# ➕ Bombas Maiores

* [x] Requer nível 100;
* [x] Habilidade Passiva.

A habilidade Bombas Maiores aumenta o alcance explosivo de TNT causado pela habilidade [Mineração Explosiva](../../../../global/mcmmo/habilidades-de-coleta/mineracao/mineracao-explosiva.md). No nível 375, adiciona 2 ao raio da explosão. No nível 625, esse bônus é aumentado para 3. E no nível 875, o raio ganha seu bônus máximo de 4. Sem essa habilidade, o TNT tem um raio de 6,9.
