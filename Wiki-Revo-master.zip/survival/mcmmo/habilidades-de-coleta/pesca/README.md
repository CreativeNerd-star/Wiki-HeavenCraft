---
description: Aprimore sua pesca com a habilidade de Pescaria!
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🎣 Pesca

![](../../../../.gitbook/assets/FishingSkill.webp)

## » Habilidades

{% content-ref url="../../../../global/mcmmo/habilidades-de-coleta/pesca/cacador-de-tesouros.md" %}
[cacador-de-tesouros.md](../../../../global/mcmmo/habilidades-de-coleta/pesca/cacador-de-tesouros.md)
{% endcontent-ref %}

{% content-ref url="../../../../global/mcmmo/habilidades-de-coleta/pesca/pesca-no-gelo.md" %}
[pesca-no-gelo.md](../../../../global/mcmmo/habilidades-de-coleta/pesca/pesca-no-gelo.md)
{% endcontent-ref %}

{% content-ref url="../../../../global/mcmmo/habilidades-de-coleta/pesca/sacudir.md" %}
[sacudir.md](../../../../global/mcmmo/habilidades-de-coleta/pesca/sacudir.md)
{% endcontent-ref %}

{% content-ref url="../../../../global/mcmmo/habilidades-de-coleta/pesca/dieta-do-pescador.md" %}
[dieta-do-pescador.md](../../../../global/mcmmo/habilidades-de-coleta/pesca/dieta-do-pescador.md)
{% endcontent-ref %}

{% content-ref url="../../../../global/mcmmo/habilidades-de-coleta/pesca/cacador-magico.md" %}
[cacador-magico.md](../../../../global/mcmmo/habilidades-de-coleta/pesca/cacador-magico.md)
{% endcontent-ref %}

{% content-ref url="../../../../global/mcmmo/habilidades-de-coleta/pesca/pescador-mestre.md" %}
[pescador-mestre.md](../../../../global/mcmmo/habilidades-de-coleta/pesca/pescador-mestre.md)
{% endcontent-ref %}

## » Técnicas

## » Tabela de EXP ganho

<table><thead><tr><th>» Peixe Pescado «</th><th align="center">» EXP «</th><th data-hidden></th></tr></thead><tbody><tr><td><img src="../../../../.gitbook/assets/Cod.webp" alt="" data-size="line"> Bacalhau</td><td align="center">100</td><td></td></tr><tr><td><img src="../../../../.gitbook/assets/Salmon.webp" alt="" data-size="line"> Salmão</td><td align="center">600</td><td></td></tr><tr><td><img src="../../../../.gitbook/assets/Pufferfish_large.webp" alt="" data-size="line"> Baiacu</td><td align="center">2400</td><td></td></tr><tr><td><img src="../../../../.gitbook/assets/20190130_213406.webp" alt="" data-size="line"> Peixe Tropical</td><td align="center">10.000</td><td></td></tr><tr><td>🗝️ <a href="../../../../global/mcmmo/habilidades-de-coleta/pesca/cacador-de-tesouros.md">Tesouros</a></td><td align="center">200</td><td></td></tr><tr><td><img src="../../../../.gitbook/assets/Olho_de_Aranha.webp" alt="" data-size="line"> Habilidade <a href="../../../../global/mcmmo/habilidades-de-coleta/pesca/sacudir.md">Sacudir</a> utilizada em Mob</td><td align="center">50</td><td></td></tr><tr><td><img src="../../../../.gitbook/assets/Rotten_Flesh_JE3_BE2.webp" alt="" data-size="line"> Qualquer item restante que não seja peixe</td><td align="center">50</td><td></td></tr></tbody></table>
