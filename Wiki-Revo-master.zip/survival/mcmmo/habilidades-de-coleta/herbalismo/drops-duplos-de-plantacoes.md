---
description: Dobre os drops na sua colheita!
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🪶 Drops Duplos de Plantações

Drops duplos é uma habilidade passiva que permite ao jogador ganhar dois itens em vez do usual ao colher qualquer plantação listada na tabela de experiência em » [Herbalismo](../../../../global/mcmmo/habilidades-de-coleta/herbalismo/) «. As chances de isso acontecer aumentam em 0,1% por nível para um máximo de 100% no nível 1000. Ele não se acumula com o encantamento Fortuna, mas funciona com o Toque Suave.
