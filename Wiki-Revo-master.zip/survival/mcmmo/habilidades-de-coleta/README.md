---
description: >-
  Habilidades de coleta são habilidades que são aprimoradas por meio de coletas
  de itens. Essas habilidades podem lhe fornecer um bônus de drops duplos, drops
  raros, melhoria na eficiência da coleta...
cover: ../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🌿 Habilidades de Coleta

## » Habilidades de coleta

{% content-ref url="../../../global/mcmmo/habilidades-de-coleta/mineracao/" %}
[mineracao](../../../global/mcmmo/habilidades-de-coleta/mineracao/)
{% endcontent-ref %}

{% content-ref url="../../../global/mcmmo/habilidades-de-coleta/lenhador/" %}
[lenhador](../../../global/mcmmo/habilidades-de-coleta/lenhador/)
{% endcontent-ref %}

{% content-ref url="../../../global/mcmmo/habilidades-de-coleta/herbalismo/" %}
[herbalismo](../../../global/mcmmo/habilidades-de-coleta/herbalismo/)
{% endcontent-ref %}

{% content-ref url="../../../global/mcmmo/habilidades-de-coleta/escavacao/" %}
[escavacao](../../../global/mcmmo/habilidades-de-coleta/escavacao/)
{% endcontent-ref %}

{% content-ref url="../../../global/mcmmo/habilidades-de-coleta/pesca/" %}
[pesca](../../../global/mcmmo/habilidades-de-coleta/pesca/)
{% endcontent-ref %}
