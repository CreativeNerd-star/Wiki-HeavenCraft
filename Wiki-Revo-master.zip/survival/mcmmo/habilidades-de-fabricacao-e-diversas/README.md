---
description: >-
  Essas habilidades podem lhe fornecer uma maior eficiência na fabricação,
  fabricações exclusivas, etc.
cover: ../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🔨 Habilidades de Fabricação e Diversas

## » Habilidades de fabricação e diversas

{% content-ref url="../../../global/mcmmo/habilidades-de-fabricacao-e-diversas/reparacao/" %}
[reparacao](../../../global/mcmmo/habilidades-de-fabricacao-e-diversas/reparacao/)
{% endcontent-ref %}

{% content-ref url="../../../global/mcmmo/habilidades-de-fabricacao-e-diversas/alquimia/" %}
[alquimia](../../../global/mcmmo/habilidades-de-fabricacao-e-diversas/alquimia/)
{% endcontent-ref %}

{% content-ref url="../../../global/mcmmo/habilidades-de-fabricacao-e-diversas/fundicao/" %}
[fundicao](../../../global/mcmmo/habilidades-de-fabricacao-e-diversas/fundicao/)
{% endcontent-ref %}

## » Habilidades diversas

{% content-ref url="../../../global/mcmmo/habilidades-de-fabricacao-e-diversas/acrobacias/" %}
[acrobacias](../../../global/mcmmo/habilidades-de-fabricacao-e-diversas/acrobacias/)
{% endcontent-ref %}
