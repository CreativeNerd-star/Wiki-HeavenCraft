---
description: >-
  Habilidades de combate podem lhe fornecer stats extra, como mais dano, mais
  resistência, etc.
cover: ../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# ⚔ Habilidades de Combate

## » Habilidades de combate

{% content-ref url="../../../global/mcmmo/habilidades-de-combate/desarmado/" %}
[desarmado](../../../global/mcmmo/habilidades-de-combate/desarmado/)
{% endcontent-ref %}

{% content-ref url="../../../global/mcmmo/habilidades-de-combate/arquearia/" %}
[arquearia](../../../global/mcmmo/habilidades-de-combate/arquearia/)
{% endcontent-ref %}

{% content-ref url="../../../global/mcmmo/habilidades-de-combate/espadas/" %}
[espadas](../../../global/mcmmo/habilidades-de-combate/espadas/)
{% endcontent-ref %}

{% content-ref url="../../../global/mcmmo/habilidades-de-combate/machados/" %}
[machados](../../../global/mcmmo/habilidades-de-combate/machados/)
{% endcontent-ref %}

{% content-ref url="../../../global/mcmmo/habilidades-de-combate/domesticacao/" %}
[domesticacao](../../../global/mcmmo/habilidades-de-combate/domesticacao/)
{% endcontent-ref %}
