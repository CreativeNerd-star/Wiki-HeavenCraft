---
description: Aprimore a luta com animais domesticáveis com esta habilidade!
cover: ../../../../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🦴 Domesticação

![](../../../../.gitbook/assets/TamingSkill.webp)

## » Habilidades

{% content-ref url="../../../../global/mcmmo/habilidades-de-combate/domesticacao/conhecimento-de-feras.md" %}
[conhecimento-de-feras.md](../../../../global/mcmmo/habilidades-de-combate/domesticacao/conhecimento-de-feras.md)
{% endcontent-ref %}

{% content-ref url="../../../../global/mcmmo/habilidades-de-combate/domesticacao/chamado-da-natureza.md" %}
[chamado-da-natureza.md](../../../../global/mcmmo/habilidades-de-combate/domesticacao/chamado-da-natureza.md)
{% endcontent-ref %}

{% content-ref url="../../../../global/mcmmo/habilidades-de-combate/domesticacao/consciencia-ambiental.md" %}
[consciencia-ambiental.md](../../../../global/mcmmo/habilidades-de-combate/domesticacao/consciencia-ambiental.md)
{% endcontent-ref %}

{% content-ref url="../../../../global/mcmmo/habilidades-de-combate/domesticacao/patada.md" %}
[patada.md](../../../../global/mcmmo/habilidades-de-combate/domesticacao/patada.md)
{% endcontent-ref %}

{% content-ref url="../../../../global/mcmmo/habilidades-de-combate/domesticacao/servico-de-fast-food.md" %}
[servico-de-fast-food.md](../../../../global/mcmmo/habilidades-de-combate/domesticacao/servico-de-fast-food.md)
{% endcontent-ref %}

{% content-ref url="../../../../global/mcmmo/habilidades-de-combate/domesticacao/mordida.md" %}
[mordida.md](../../../../global/mcmmo/habilidades-de-combate/domesticacao/mordida.md)
{% endcontent-ref %}

{% content-ref url="../../../../global/mcmmo/habilidades-de-combate/domesticacao/pelo-grosso.md" %}
[pelo-grosso.md](../../../../global/mcmmo/habilidades-de-combate/domesticacao/pelo-grosso.md)
{% endcontent-ref %}

{% content-ref url="../../../../global/mcmmo/habilidades-de-combate/domesticacao/cao-piedoso.md" %}
[cao-piedoso.md](../../../../global/mcmmo/habilidades-de-combate/domesticacao/cao-piedoso.md)
{% endcontent-ref %}

{% content-ref url="../../../../global/mcmmo/habilidades-de-combate/domesticacao/resistencia-a-impactos.md" %}
[resistencia-a-impactos.md](../../../../global/mcmmo/habilidades-de-combate/domesticacao/resistencia-a-impactos.md)
{% endcontent-ref %}

{% content-ref url="../../../../global/mcmmo/habilidades-de-combate/domesticacao/garras-afiadas.md" %}
[garras-afiadas.md](../../../../global/mcmmo/habilidades-de-combate/domesticacao/garras-afiadas.md)
{% endcontent-ref %}

## » Técnicas

## » Tabela de EXP ganho
