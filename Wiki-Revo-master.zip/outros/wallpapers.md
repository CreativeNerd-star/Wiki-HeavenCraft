---
description: >-
  Obtenha aqui alguns wallpapers para deixar seu dispositivo ainda mais
  elegante.
---

# Wallpapers

<figure><img src="../.gitbook/assets/thiagogebrim e Nevisk.png" alt=""><figcaption><p>thiagogebrim e Nevisk segurando o Revonildo</p></figcaption></figure>

<figure><img src="../.gitbook/assets/Festa Junina com Beazika, Nevisk e thiagogebrim.png" alt=""><figcaption><p>Beazika, Nevisk e thiagogebrim comemorando a Festa Junina</p></figcaption></figure>

<figure><img src="../.gitbook/assets/Felipesfera caixa tradições wallpaper.png" alt=""><figcaption><p>Felipesfera abrindo a caixa das Tradições Brasileiras</p></figcaption></figure>

<figure><img src="../.gitbook/assets/thiagogebrim e julg lgbt wallpaper.png" alt=""><figcaption><p>thiagogebrim e julgzin segurando bandeiras LGBTQIA+</p></figcaption></figure>

<figure><img src="../.gitbook/assets/Beazika wallpaper.png" alt=""><figcaption><p>Beazika jogando</p></figcaption></figure>
