---
description: >-
  Um resource pack feito por nossa equipe para deixar o jogo mais divertido e
  interativo
cover: ../.gitbook/assets/Inserir_um_titulo_3.png
coverY: 0
---

# 🎮 Revo Pack

### Lista de emojis para utilizar no servidor

<img src="../.gitbook/assets/peposleep.png" alt="" data-size="line"> = :peposleep:\
<img src="../.gitbook/assets/GG.png" alt="" data-size="line"> = :gg: \
<img src="../.gitbook/assets/revo.png" alt="" data-size="line"> = :revo:\
<img src="../.gitbook/assets/pray.png" alt="" data-size="line"> = :pray: ou :reza: \
<img src="../.gitbook/assets/flushed.png" alt="" data-size="line"> = :flushed: ou :evergonhado: \
<img src="../.gitbook/assets/kekw.png" alt="" data-size="line"> = :kekw: \
<img src="../.gitbook/assets/f.png" alt="" data-size="line"> = :f: \
<img src="../.gitbook/assets/sunglasses.png" alt="" data-size="line"> = :sunglasses:\
<img src="../.gitbook/assets/emerald.png" alt="" data-size="line"> = :emerald: ou :esmeralda: \
<img src="../.gitbook/assets/clown.png" alt="" data-size="line"> = :clown: ou :palhaço: \
<img src="../.gitbook/assets/sob.png" alt="" data-size="line"> = :chorando: ou :sob:\
<img src="../.gitbook/assets/heart_eyes.png" alt="" data-size="line"> = :apaixonado: ou :heart\_eyes:\
<img src="../.gitbook/assets/pleading_face.png" alt="" data-size="line"> = :pleading\_face: ou :drama: \
<img src="../.gitbook/assets/angry.png" alt="" data-size="line"> = :angry: ou :nervoso: \
<img src="../.gitbook/assets/like.png" alt="" data-size="line"> = :like:, :joia: ou :thumbsup: \
<img src="../.gitbook/assets/sunglasso_bravo.png" alt="" data-size="line"> = :sunglasso\_bravo: \
<img src="../.gitbook/assets/rofl.png" alt="" data-size="line"> = :rofl: ou :risos:

